import { Route, Routes } from 'react-router-dom'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import Home from './pages/Home'
import Register from './pages/Register'
import Login from './pages/Login'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'
import Payment from './pages/Payment'
import Entrance from './pages/Entrance'
import Dashboard from './pages/Dashboard'
import Suspended from './pages/Suspended'
import OwnerPayments from './pages/owner/OwnerPayments'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        <Route
          path="/payment"
          element={<ProtectedRoute allow={['pending_payment', 'payment_under_review']}><Payment /></ProtectedRoute>}
        />
        <Route
          path="/entrance"
          element={<ProtectedRoute allow={['payment_approved', 'entrance_pending']}><Entrance /></ProtectedRoute>}
        />
        <Route
          path="/dashboard"
          element={<ProtectedRoute allow={['active']}><Dashboard /></ProtectedRoute>}
        />
        <Route
          path="/suspended"
          element={<ProtectedRoute allow={['suspended']}><Suspended /></ProtectedRoute>}
        />

        <Route
          path="/owner/payments"
          element={<ProtectedRoute requireOwner><OwnerPayments /></ProtectedRoute>}
        />

        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
