export default function Suspended() {
  return (
    <section className="mx-auto max-w-xl px-4 py-16">
      <div className="panel">
        <h1 className="text-3xl font-extrabold">Your account is suspended</h1>
        <p className="mt-4">
          You cannot use SKILLFORGE while your account is suspended. Contact the SKILLFORGE team through the channel
          you were given to resolve this.
        </p>
      </div>
    </section>
  )
}
