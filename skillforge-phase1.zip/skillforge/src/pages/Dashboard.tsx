import { useAuth } from '../context/AuthContext'

export default function Dashboard() {
  const { profile } = useAuth()
  const firstName = profile?.full_name.split(' ')[0] ?? 'Student'

  return (
    <section className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="text-4xl font-extrabold">Welcome, {firstName}</h1>
      <div className="panel mt-8">
        <p className="text-lg">Your account is active.</p>
        <p className="mt-4 text-ink/80">
          Department: {profile?.department}. Lessons, practice tests and timed exams are added in the next development
          phases.
        </p>
      </div>
    </section>
  )
}
