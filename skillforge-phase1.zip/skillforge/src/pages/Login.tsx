import { FormEvent, useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

function friendlyError(message: string) {
  if (/invalid login/i.test(message)) return 'Email or password is incorrect.'
  if (/not confirmed/i.test(message)) return 'Confirm your email first. Check your inbox for the link.'
  return message
}

export default function Login() {
  const navigate = useNavigate()
  const location = useLocation()
  const { refreshProfile } = useAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    })

    if (signInError) {
      setSubmitting(false)
      setError(friendlyError(signInError.message))
      return
    }

    const profile = await refreshProfile()
    setSubmitting(false)

    const from = (location.state as { from?: string } | null)?.from
    const fallback = profile?.role === 'owner' ? '/owner/payments' : '/dashboard'
    navigate(from ?? fallback, { replace: true })
  }

  return (
    <section className="mx-auto max-w-md px-4 py-12">
      <h1 className="text-4xl font-extrabold">Log in</h1>

      <form onSubmit={handleSubmit} className="panel mt-8 space-y-5">
        <div>
          <label htmlFor="email" className="label">Email address</label>
          <input
            id="email"
            type="email"
            className="field"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div>
          <label htmlFor="password" className="label">Password</label>
          <input
            id="password"
            type="password"
            className="field"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        {error && <p role="alert" className="error-text">{error}</p>}

        <button type="submit" className="btn-primary w-full" disabled={submitting}>
          {submitting ? 'Logging in…' : 'Log in'}
        </button>

        <div className="flex flex-wrap justify-between gap-2 text-sm font-bold">
          <Link to="/forgot-password" className="underline">Forgot password?</Link>
          <Link to="/register" className="underline">Create an account</Link>
        </div>
      </form>
    </section>
  )
}
