import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import type { PaymentSubmission } from '../../lib/types'
import { PAYMENT } from '../../config/site'

type Filter = 'pending' | 'approved' | 'rejected' | 'all'
const FILTERS: Filter[] = ['pending', 'approved', 'rejected', 'all']

const statusTone: Record<PaymentSubmission['status'], string> = {
  pending: 'bg-marigold/25',
  approved: 'bg-sage text-paper',
  rejected: 'bg-brick text-paper',
}

export default function OwnerPayments() {
  const [filter, setFilter] = useState<Filter>('pending')
  const [rows, setRows] = useState<PaymentSubmission[]>([])
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState<string | null>(null)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [rejectingId, setRejectingId] = useState<string | null>(null)
  const [reason, setReason] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    let query = supabase
      .from('payment_submissions')
      .select('*, profiles!payment_submissions_user_id_fkey(full_name, username, phone, email, department)')
      .order('created_at', { ascending: false })
    if (filter !== 'all') query = query.eq('status', filter)
    const { data, error } = await query
    if (error) setMessage(`Could not load payments: ${error.message}`)
    setRows((data as unknown as PaymentSubmission[]) ?? [])
    setLoading(false)
  }, [filter])

  useEffect(() => {
    load()
  }, [load])

  async function viewReceipt(path: string) {
    const { data, error } = await supabase.storage.from('payment-receipts').createSignedUrl(path, 300)
    if (error || !data) {
      setMessage('The receipt could not be opened.')
      return
    }
    window.open(data.signedUrl, '_blank', 'noopener,noreferrer')
  }

  async function approve(id: string) {
    setBusyId(id)
    setMessage(null)
    const { error } = await supabase.rpc('approve_payment', { p_submission_id: id })
    setBusyId(null)
    setMessage(error ? error.message : 'Payment approved. The student can now take the entrance examination.')
    if (!error) load()
  }

  async function reject(id: string) {
    if (reason.trim().length < 5) {
      setMessage('Write a reason of at least 5 characters so the student knows what to fix.')
      return
    }
    setBusyId(id)
    setMessage(null)
    const { error } = await supabase.rpc('reject_payment', {
      p_submission_id: id,
      p_reason: reason.trim(),
    })
    setBusyId(null)
    if (error) {
      setMessage(error.message)
      return
    }
    setMessage('Payment rejected. The student has been asked to resubmit.')
    setRejectingId(null)
    setReason('')
    load()
  }

  return (
    <section className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-4xl font-extrabold">Payment review</h1>
      <p className="mt-3 text-ink/80">
        Check each transfer in your OPay account before approving. Account {PAYMENT.accountNumber}, name {PAYMENT.accountName}.
      </p>

      <div role="tablist" aria-label="Filter payments" className="mt-6 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f}
            role="tab"
            aria-selected={filter === f}
            onClick={() => setFilter(f)}
            className={`rounded-full border-2 px-4 py-2 text-sm font-bold capitalize ${
              filter === f ? 'border-ink bg-ink text-paper' : 'border-ink/20 bg-white'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {message && <p role="status" className="mt-6 rounded-lg bg-white p-4 font-semibold shadow-sm">{message}</p>}

      {loading ? (
        <p className="mt-8">Loading payments…</p>
      ) : rows.length === 0 ? (
        <p className="mt-8 panel">No payments in this list.</p>
      ) : (
        <ul className="mt-8 space-y-5">
          {rows.map((row) => (
            <li key={row.id} className="panel">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl font-bold">{row.profiles?.full_name ?? 'Unknown student'}</h2>
                  <p className="text-sm text-ink/80">
                    @{row.profiles?.username} · {row.profiles?.department} · {row.profiles?.phone} · {row.profiles?.email}
                  </p>
                </div>
                <span className={`rounded-full px-3 py-1 text-sm font-bold capitalize ${statusTone[row.status]}`}>
                  {row.status}
                </span>
              </div>

              <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-3">
                <div><dt className="font-bold">Reference</dt><dd className="break-all">{row.payment_reference}</dd></div>
                <div><dt className="font-bold">Payment date</dt><dd>{row.payment_date}</dd></div>
                <div><dt className="font-bold">Submitted</dt><dd>{new Date(row.created_at).toLocaleString()}</dd></div>
              </dl>

              {row.rejection_reason && (
                <p className="mt-3 text-sm"><strong>Rejection reason:</strong> {row.rejection_reason}</p>
              )}

              <div className="mt-5 flex flex-wrap gap-3">
                {row.receipt_path ? (
                  <button onClick={() => viewReceipt(row.receipt_path!)} className="btn-ghost px-4 py-2 text-sm">
                    View receipt
                  </button>
                ) : (
                  <span className="self-center text-sm text-ink/70">No receipt uploaded</span>
                )}

                {row.status === 'pending' && (
                  <>
                    <button
                      onClick={() => approve(row.id)}
                      disabled={busyId === row.id}
                      className="btn-primary px-4 py-2 text-sm"
                    >
                      Approve payment
                    </button>
                    <button
                      onClick={() => { setRejectingId(row.id); setReason('') }}
                      className="btn-ghost px-4 py-2 text-sm"
                    >
                      Reject payment
                    </button>
                  </>
                )}
              </div>

              {rejectingId === row.id && (
                <div className="mt-4 space-y-3 rounded-lg bg-paper p-4">
                  <label htmlFor={`reason-${row.id}`} className="label">Reason for rejection (the student will see this)</label>
                  <textarea
                    id={`reason-${row.id}`}
                    className="field min-h-24"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    placeholder="For example: No transfer to the account name Ogunlowo Sodiq was found."
                  />
                  <div className="flex gap-3">
                    <button onClick={() => reject(row.id)} disabled={busyId === row.id} className="btn-primary px-4 py-2 text-sm">
                      Confirm rejection
                    </button>
                    <button onClick={() => setRejectingId(null)} className="btn-ghost px-4 py-2 text-sm">
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}
