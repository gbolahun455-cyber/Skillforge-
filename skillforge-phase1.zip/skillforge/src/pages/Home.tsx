import { Link } from 'react-router-dom'
import { REGISTRATION_FEE_NGN } from '../config/site'

const steps = [
  { title: 'Create your account', text: 'Enter your details and choose your department.' },
  { title: `Pay ₦${REGISTRATION_FEE_NGN} once`, text: 'Send the one-time activation fee, then submit your payment reference.' },
  { title: 'Wait for approval', text: 'The SKILLFORGE team checks each payment before your account is activated.' },
  { title: 'Pass the entrance examination', text: 'Your learning dashboard opens after you pass.' },
]

export default function Home() {
  return (
    <section className="mx-auto grid max-w-6xl gap-12 px-4 py-14 md:grid-cols-2 md:items-center md:py-20">
      <div>
        <h1 className="text-5xl font-extrabold leading-[1.02] md:text-6xl">
          Learn. Build. Create. Grow.
        </h1>
        <p className="mt-6 max-w-prose text-lg leading-relaxed">
          SKILLFORGE is an online school for secondary students. Practice tests, timed exams,
          teachers and live coaching are kept together in one place.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/register" className="btn-accent">Create an account</Link>
          <Link to="/login" className="btn-ghost">Log in</Link>
        </div>
      </div>

      <ol className="ruled-page rounded-2xl border-2 border-ink bg-white p-6 md:p-8">
        {steps.map((step, index) => (
          <li key={step.title} className="flex gap-4 border-b border-ink/10 py-4 last:border-b-0">
            <span className="font-display text-2xl font-extrabold text-brick" aria-hidden="true">{index + 1}</span>
            <div>
              <h2 className="text-lg font-bold">{step.title}</h2>
              <p className="mt-1 text-ink/80">{step.text}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  )
}
