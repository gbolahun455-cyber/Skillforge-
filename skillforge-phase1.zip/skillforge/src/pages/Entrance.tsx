import { useAuth } from '../context/AuthContext'
import StatusBadge from '../components/StatusBadge'

export default function Entrance() {
  const { profile } = useAuth()
  if (!profile) return null

  return (
    <section className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-4xl font-extrabold">Entrance examination</h1>
      <div className="mt-4"><StatusBadge status={profile.account_status} /></div>

      <div className="panel mt-8">
        <p className="text-lg">Your payment has been approved.</p>
        <p className="mt-4">
          The entrance examination is built in the next development phase. Your learning dashboard stays locked until
          you pass it.
        </p>
      </div>
    </section>
  )
}
