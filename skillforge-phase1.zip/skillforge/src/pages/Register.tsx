import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { DEPARTMENTS, REGISTRATION_FEE_NGN } from '../config/site'
import Field from '../components/Field'
import type { Department } from '../lib/types'

interface Form {
  fullName: string
  username: string
  phone: string
  email: string
  password: string
  department: Department | ''
}

type FormErrors = Partial<Record<keyof Form, string>>

const emptyForm: Form = { fullName: '', username: '', phone: '', email: '', password: '', department: '' }

function normalisePhone(value: string) {
  return value.replace(/[\s-]/g, '')
}

function validate(f: Form): FormErrors {
  const e: FormErrors = {}
  if (f.fullName.trim().length < 3) e.fullName = 'Enter your full name. It must be at least 3 characters.'
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(f.username)) e.username = 'Use 3 to 20 letters, numbers or underscores.'
  if (!/^\+?[0-9]{10,15}$/.test(normalisePhone(f.phone))) e.phone = 'Enter a valid phone number.'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.trim())) e.email = 'Enter a valid email address.'
  if (f.password.length < 8) e.password = 'Password must be at least 8 characters.'
  if (!f.department) e.department = 'Choose Science, Art or Commercial.'
  return e
}

function friendlyError(message: string) {
  if (/already registered/i.test(message)) return 'An account with this email already exists. Log in instead.'
  if (/database error/i.test(message)) {
    return 'We could not create your account. The username or phone number may already be in use.'
  }
  return message
}

export default function Register() {
  const navigate = useNavigate()
  const { refreshProfile } = useAuth()
  const [form, setForm] = useState<Form>(emptyForm)
  const [errors, setErrors] = useState<FormErrors>({})
  const [usernameState, setUsernameState] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle')
  const [formError, setFormError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [needsEmailConfirmation, setNeedsEmailConfirmation] = useState(false)

  function update<K extends keyof Form>(key: K, value: Form[K]) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  async function checkUsername() {
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(form.username)) return
    setUsernameState('checking')
    const { data, error } = await supabase.rpc('is_username_available', { p_username: form.username })
    if (error) {
      setUsernameState('idle')
      return
    }
    setUsernameState(data ? 'available' : 'taken')
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setFormError(null)

    const found = validate(form)
    setErrors(found)
    if (Object.keys(found).length > 0) return

    if (usernameState === 'taken') {
      setErrors({ username: 'That username is taken. Choose another.' })
      return
    }

    setSubmitting(true)
    const { data, error } = await supabase.auth.signUp({
      email: form.email.trim(),
      password: form.password,
      options: {
        data: {
          full_name: form.fullName.trim(),
          username: form.username,
          phone: normalisePhone(form.phone),
          department: form.department,
        },
      },
    })
    setSubmitting(false)

    if (error) {
      setFormError(friendlyError(error.message))
      return
    }

    if (data.session) {
      await refreshProfile()
      navigate('/payment', { replace: true })
    } else {
      setNeedsEmailConfirmation(true)
    }
  }

  if (needsEmailConfirmation) {
    return (
      <section className="mx-auto max-w-xl px-4 py-16">
        <div className="panel">
          <h1 className="text-3xl font-extrabold">Confirm your email</h1>
          <p className="mt-4">
            We sent a confirmation link to <strong>{form.email.trim()}</strong>. Open it, then log in
            to pay the ₦{REGISTRATION_FEE_NGN} activation fee.
          </p>
          <Link to="/login" className="btn-primary mt-6">Go to log in</Link>
        </div>
      </section>
    )
  }

  return (
    <section className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-4xl font-extrabold">Create your account</h1>
      <p className="mt-3 text-ink/80">
        After you register, you will pay the one-time ₦{REGISTRATION_FEE_NGN} activation fee.
      </p>

      <form onSubmit={handleSubmit} noValidate className="panel mt-8 space-y-5">
        <Field id="fullName" label="Full name" error={errors.fullName}>
          <input
            id="fullName"
            className="field"
            autoComplete="name"
            value={form.fullName}
            onChange={(e) => update('fullName', e.target.value)}
          />
        </Field>

        <Field
          id="username"
          label="Username"
          error={errors.username}
          hint={
            usernameState === 'checking' ? 'Checking availability…'
            : usernameState === 'available' ? 'Username is available.'
            : '3 to 20 letters, numbers or underscores.'
          }
        >
          <input
            id="username"
            className="field"
            autoComplete="username"
            value={form.username}
            onChange={(e) => { update('username', e.target.value); setUsernameState('idle') }}
            onBlur={checkUsername}
          />
        </Field>

        <Field id="phone" label="Phone number" error={errors.phone}>
          <input
            id="phone"
            className="field"
            inputMode="tel"
            autoComplete="tel"
            placeholder="08012345678"
            value={form.phone}
            onChange={(e) => update('phone', e.target.value)}
          />
        </Field>

        <Field id="email" label="Email address" error={errors.email}>
          <input
            id="email"
            type="email"
            className="field"
            autoComplete="email"
            value={form.email}
            onChange={(e) => update('email', e.target.value)}
          />
        </Field>

        <Field id="password" label="Password" error={errors.password} hint="At least 8 characters.">
          <input
            id="password"
            type="password"
            className="field"
            autoComplete="new-password"
            value={form.password}
            onChange={(e) => update('password', e.target.value)}
          />
        </Field>

        <fieldset>
          <legend className="label">Department</legend>
          <div className="grid grid-cols-3 gap-2">
            {DEPARTMENTS.map((d) => (
              <label
                key={d}
                className={`cursor-pointer rounded-lg border-2 px-3 py-3 text-center font-bold focus-within:ring-4 focus-within:ring-marigold ${
                  form.department === d ? 'border-ink bg-ink text-paper' : 'border-ink/20 bg-white'
                }`}
              >
                <input
                  type="radio"
                  name="department"
                  value={d}
                  checked={form.department === d}
                  onChange={() => update('department', d)}
                  className="sr-only"
                />
                {d}
              </label>
            ))}
          </div>
          {errors.department && <p role="alert" className="error-text mt-1">{errors.department}</p>}
        </fieldset>

        {formError && <p role="alert" className="error-text">{formError}</p>}

        <button type="submit" className="btn-primary w-full" disabled={submitting}>
          {submitting ? 'Creating your account…' : 'Create account'}
        </button>

        <p className="text-center text-sm">
          Already registered? <Link to="/login" className="font-bold underline">Log in</Link>
        </p>
      </form>
    </section>
  )
}
