import { FormEvent, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function ResetPassword() {
  const navigate = useNavigate()
  const { session, loading, refreshProfile } = useAuth()
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  if (loading) return <p className="p-10 text-center">Checking your reset link…</p>

  if (!session) {
    return (
      <section className="mx-auto max-w-md px-4 py-12">
        <div className="panel">
          <h1 className="text-3xl font-extrabold">This link has expired</h1>
          <p className="mt-4">Request a new reset link to choose a new password.</p>
          <Link to="/forgot-password" className="btn-primary mt-6">Request a new link</Link>
        </div>
      </section>
    )
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    if (password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }
    if (password !== confirm) {
      setError('The two passwords do not match.')
      return
    }
    setSubmitting(true)
    const { error: updateError } = await supabase.auth.updateUser({ password })
    setSubmitting(false)
    if (updateError) {
      setError(updateError.message)
      return
    }
    await refreshProfile()
    navigate('/dashboard', { replace: true })
  }

  return (
    <section className="mx-auto max-w-md px-4 py-12">
      <h1 className="text-4xl font-extrabold">Choose a new password</h1>
      <form onSubmit={handleSubmit} className="panel mt-8 space-y-5">
        <div>
          <label htmlFor="password" className="label">New password</label>
          <input id="password" type="password" className="field" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div>
          <label htmlFor="confirm" className="label">Confirm new password</label>
          <input id="confirm" type="password" className="field" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </div>
        {error && <p role="alert" className="error-text">{error}</p>}
        <button type="submit" className="btn-primary w-full" disabled={submitting}>
          {submitting ? 'Saving…' : 'Save new password'}
        </button>
      </form>
    </section>
  )
}
