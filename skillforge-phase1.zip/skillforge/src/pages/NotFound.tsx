import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <section className="mx-auto max-w-xl px-4 py-20 text-center">
      <h1 className="text-4xl font-extrabold">Page not found</h1>
      <p className="mt-4">The page you opened does not exist.</p>
      <Link to="/" className="btn-primary mt-8">Go to the home page</Link>
    </section>
  )
}
