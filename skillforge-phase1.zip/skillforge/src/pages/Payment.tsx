import { ChangeEvent, FormEvent, useCallback, useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { PAYMENT, REGISTRATION_FEE_NGN } from '../config/site'
import { pathForStatus } from '../lib/status'
import type { PaymentSubmission } from '../lib/types'
import Field from '../components/Field'
import StatusBadge from '../components/StatusBadge'

const MAX_RECEIPT_BYTES = 5 * 1024 * 1024
const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
const today = new Date().toISOString().slice(0, 10)

function friendlyError(message: string) {
  if (/payment_reference_unique|duplicate key/i.test(message)) {
    return 'This payment reference has already been submitted. Check the reference and try again.'
  }
  return message
}

export default function Payment() {
  const { session, profile, refreshProfile } = useAuth()
  const [latest, setLatest] = useState<PaymentSubmission | null>(null)
  const [reference, setReference] = useState('')
  const [paymentDate, setPaymentDate] = useState(today)
  const [file, setFile] = useState<File | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [copied, setCopied] = useState(false)

  const loadLatest = useCallback(async () => {
    if (!session) return
    const { data } = await supabase
      .from('payment_submissions')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle()
    setLatest((data as PaymentSubmission | null) ?? null)
  }, [session])

  useEffect(() => {
    loadLatest()
  }, [loadLatest])

  if (!profile) return null

  if (profile.account_status !== 'pending_payment' && profile.account_status !== 'payment_under_review') {
    return <Navigate to={pathForStatus(profile.account_status)} replace />
  }

  async function copyAccountNumber() {
    await navigator.clipboard.writeText(PAYMENT.accountNumber)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const chosen = e.target.files?.[0] ?? null
    setError(null)
    if (chosen && !ACCEPTED_TYPES.includes(chosen.type)) {
      setError('Upload a JPG, PNG, WEBP or PDF receipt.')
      setFile(null)
      return
    }
    if (chosen && chosen.size > MAX_RECEIPT_BYTES) {
      setError('The receipt must be 5 MB or smaller.')
      setFile(null)
      return
    }
    setFile(chosen)
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!session) return
    setError(null)

    if (reference.trim().length < 6) {
      setError('Enter the payment reference or transaction ID. It must be at least 6 characters.')
      return
    }
    if (!paymentDate || paymentDate > today) {
      setError('Enter the date you made the payment. It cannot be in the future.')
      return
    }

    setSubmitting(true)

    let receiptPath: string | null = null
    if (file) {
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const path = `${session.user.id}/${Date.now()}-${safeName}`
      const { error: uploadError } = await supabase.storage
        .from('payment-receipts')
        .upload(path, file, { contentType: file.type, upsert: false })
      if (uploadError) {
        setSubmitting(false)
        setError('The receipt could not be uploaded. Try again, or submit without a receipt.')
        return
      }
      receiptPath = path
    }

    const { error: submitError } = await supabase.rpc('submit_payment', {
      p_reference: reference.trim(),
      p_payment_date: paymentDate,
      p_receipt_path: receiptPath,
    })

    setSubmitting(false)
    if (submitError) {
      setError(friendlyError(submitError.message))
      return
    }

    setReference('')
    setFile(null)
    await refreshProfile()
    await loadLatest()
  }

  const underReview = profile.account_status === 'payment_under_review'
  const wasRejected = latest?.status === 'rejected' && !underReview

  return (
    <section className="mx-auto max-w-5xl px-4 py-12">
      <h1 className="text-4xl font-extrabold">Activation payment</h1>
      <p className="mt-3 max-w-prose text-ink/80">
        Pay the one-time ₦{REGISTRATION_FEE_NGN} activation fee. Your account stays locked until the SKILLFORGE team
        verifies the payment.
      </p>

      <div className="mt-6 flex items-center gap-3">
        <span className="text-sm font-bold">Current status:</span>
        <StatusBadge status={profile.account_status} />
      </div>

      <div className="mt-8 grid gap-8 md:grid-cols-2">
        <div className="ruled-page rounded-2xl border-2 border-ink bg-white p-6">
          <h2 className="text-2xl font-bold">Send the payment</h2>
          <dl className="mt-5 space-y-4">
            <div>
              <dt className="text-sm font-bold">Payment method</dt>
              <dd className="text-lg">{PAYMENT.method}</dd>
            </div>
            <div>
              <dt className="text-sm font-bold">Account number</dt>
              <dd className="flex flex-wrap items-center gap-3">
                <span className="font-display text-2xl font-extrabold tracking-wider">{PAYMENT.accountNumber}</span>
                <button type="button" onClick={copyAccountNumber} className="btn-ghost px-3 py-1 text-sm">
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </dd>
            </div>
            <div>
              <dt className="text-sm font-bold">Account name</dt>
              <dd className="text-lg">{PAYMENT.accountName}</dd>
            </div>
            <div>
              <dt className="text-sm font-bold">Amount</dt>
              <dd className="text-lg">₦{PAYMENT.amountNgn}</dd>
            </div>
          </dl>
          <p className="mt-6 rounded-lg bg-marigold/25 p-4 text-sm font-semibold">
            Before you transfer, check that the account name is exactly <strong>{PAYMENT.accountName}</strong>.
            Do not send money to any other name or account.
          </p>
        </div>

        <div>
          {underReview ? (
            <div className="panel">
              <h2 className="text-2xl font-bold">Payment under review</h2>
              <p className="mt-3">
                We have your payment details. The SKILLFORGE team will check the transfer and approve your account.
                You do not need to submit anything else.
              </p>
              {latest && (
                <dl className="mt-5 space-y-2 text-sm">
                  <div><dt className="inline font-bold">Reference: </dt><dd className="inline">{latest.payment_reference}</dd></div>
                  <div><dt className="inline font-bold">Payment date: </dt><dd className="inline">{latest.payment_date}</dd></div>
                </dl>
              )}
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate className="panel space-y-5">
              <h2 className="text-2xl font-bold">Submit your payment</h2>

              {wasRejected && latest?.rejection_reason && (
                <p role="alert" className="rounded-lg bg-brick/10 p-4 text-sm">
                  <strong>Your last submission was not accepted.</strong> Reason: {latest.rejection_reason}
                </p>
              )}

              <Field id="reference" label="Payment reference or transaction ID" hint="Copy this from your bank or OPay receipt.">
                <input
                  id="reference"
                  className="field"
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  autoComplete="off"
                />
              </Field>

              <Field id="paymentDate" label="Date you paid">
                <input
                  id="paymentDate"
                  type="date"
                  className="field"
                  max={today}
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                />
              </Field>

              <Field id="receipt" label="Receipt screenshot (optional)" hint="JPG, PNG, WEBP or PDF, up to 5 MB.">
                <input
                  id="receipt"
                  type="file"
                  accept="image/jpeg,image/png,image/webp,application/pdf"
                  className="field file:mr-4 file:rounded-md file:border-0 file:bg-ink file:px-3 file:py-2 file:font-bold file:text-paper"
                  onChange={handleFileChange}
                />
              </Field>

              {error && <p role="alert" className="error-text">{error}</p>}

              <button type="submit" className="btn-primary w-full" disabled={submitting}>
                {submitting ? 'Sending your payment details…' : 'Submit payment details'}
              </button>

              <p className="text-sm text-ink/70">
                Uploading a receipt does not activate your account. The team must confirm the payment first.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}
