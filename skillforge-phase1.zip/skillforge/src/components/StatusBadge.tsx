import { AccountStatus, STATUS_LABELS } from '../lib/status'

const tone: Record<AccountStatus, string> = {
  pending_payment: 'bg-marigold/25 text-ink',
  payment_under_review: 'bg-ink/10 text-ink',
  payment_approved: 'bg-sage/20 text-ink',
  entrance_pending: 'bg-sage/20 text-ink',
  active: 'bg-sage text-paper',
  suspended: 'bg-brick text-paper',
}

export default function StatusBadge({ status }: { status: AccountStatus }) {
  return (
    <span className={`inline-block rounded-full px-3 py-1 text-sm font-bold ${tone[status]}`}>
      {STATUS_LABELS[status]}
    </span>
  )
}
