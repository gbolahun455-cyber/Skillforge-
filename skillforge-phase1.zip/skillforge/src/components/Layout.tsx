import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Layout() {
  const { session, profile, signOut } = useAuth()
  const navigate = useNavigate()

  async function handleSignOut() {
    await signOut()
    navigate('/', { replace: true })
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-10 border-b border-ink/15 bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4">
          <Link to="/" className="font-display text-xl font-extrabold tracking-tight">
            SKILLFORGE
          </Link>
          <nav className="flex items-center gap-2 text-sm font-bold sm:gap-3">
            {!session && (
              <>
                <NavLink to="/login" className="rounded-lg px-3 py-2 hover:bg-ink/5">Log in</NavLink>
                <Link to="/register" className="btn-primary px-4 py-2 text-sm">Register</Link>
              </>
            )}
            {session && profile?.role === 'owner' && (
              <NavLink to="/owner/payments" className="rounded-lg px-3 py-2 hover:bg-ink/5">Owner</NavLink>
            )}
            {session && (
              <button onClick={handleSignOut} className="rounded-lg px-3 py-2 underline underline-offset-4 hover:bg-ink/5">
                Log out
              </button>
            )}
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="border-t border-ink/15 py-6 text-center text-sm text-ink/70">
        SKILLFORGE. Learn. Build. Create. Grow.
      </footer>
    </div>
  )
}
