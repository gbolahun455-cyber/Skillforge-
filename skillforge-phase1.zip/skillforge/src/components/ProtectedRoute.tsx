import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { AccountStatus, pathForStatus } from '../lib/status'

interface ProtectedRouteProps {
  children: ReactNode
  requireOwner?: boolean
  allow?: AccountStatus[]
}

// Frontend guard for good user experience only. The real protection is in
// Supabase Row Level Security and the database functions.
export default function ProtectedRoute({ children, requireOwner = false, allow }: ProtectedRouteProps) {
  const { session, profile, loading } = useAuth()
  const location = useLocation()

  if (loading) {
    return <p className="p-10 text-center text-ink/70">Loading your SKILLFORGE account…</p>
  }

  if (!session) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />
  }

  if (!profile) {
    return (
      <p className="p-10 text-center">
        We could not load your profile. Log out and log in again. If this continues, contact the SKILLFORGE team.
      </p>
    )
  }

  if (requireOwner) {
    return profile.role === 'owner' ? <>{children}</> : <Navigate to="/dashboard" replace />
  }

  if (allow && !allow.includes(profile.account_status)) {
    return <Navigate to={pathForStatus(profile.account_status)} replace />
  }

  return <>{children}</>
}
