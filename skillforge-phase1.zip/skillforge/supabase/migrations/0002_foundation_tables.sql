-- =====================================================================
-- SKILLFORGE, foundation tables for later phases.
-- Creating them now keeps one schema for the whole project.
-- Owner-only by default. Student-facing read access is added in each phase.
-- Run after 0001.
-- =====================================================================

-- ---------- SUBJECTS AND SYLLABUS ----------
create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.syllabus_topics (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  title text not null,
  objective text,
  sort_order integer not null default 0,
  -- Only add objectives that have been checked against the official syllabus.
  source_checked boolean not null default false,
  unique (subject_id, title)
);

-- ---------- QUESTION BANK ----------
-- Holds the correct answers, so students must NOT read this table directly.
-- Students will get questions through server functions that hide the answer
-- until a submission is marked.
create table public.question_bank (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete restrict,
  topic_id uuid references public.syllabus_topics(id) on delete set null,
  question_text text not null,
  options jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) = 4),
  correct_index smallint not null check (correct_index between 0 and 3),
  explanation text,
  difficulty text not null check (difficulty in ('easy', 'medium', 'hard')),
  -- Keeps AI-generated questions from being labelled as official past questions.
  source_type text not null check (source_type in ('past_question', 'ai_generated', 'owner_written')),
  source_note text,
  verification_status text not null default 'unverified' check (verification_status in ('unverified', 'approved', 'rejected')),
  created_by uuid references public.profiles(id) on delete set null,
  approved_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  check (source_type <> 'past_question' or source_note is not null),
  check (source_type <> 'ai_generated' or verification_status <> 'approved' or approved_by is not null)
);

-- ---------- EXAMINATIONS (entrance, practice, CBT) ----------
create table public.cbt_exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  purpose text not null check (purpose in ('entrance', 'practice', 'cbt')),
  subject_id uuid references public.subjects(id) on delete set null,
  duration_minutes integer not null check (duration_minutes between 5 and 240),
  pass_mark_percent integer not null default 50 check (pass_mark_percent between 0 and 100),
  allow_retakes boolean not null default false,
  negative_marking boolean not null default false,
  starts_at timestamptz,
  ends_at timestamptz,
  is_published boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.cbt_exam_questions (
  exam_id uuid not null references public.cbt_exams(id) on delete cascade,
  question_id uuid not null references public.question_bank(id) on delete restrict,
  sort_order integer not null default 0,
  marks integer not null default 1 check (marks > 0),
  primary key (exam_id, question_id)
);

create table public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.cbt_exams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz not null default now(),
  deadline_at timestamptz not null,
  submitted_at timestamptz,
  score numeric(7,2),
  max_score numeric(7,2),
  passed boolean
);
create index exam_attempts_user_exam_idx on public.exam_attempts (user_id, exam_id);

create table public.exam_answers (
  attempt_id uuid not null references public.exam_attempts(id) on delete cascade,
  question_id uuid not null references public.question_bank(id) on delete restrict,
  selected_index smallint check (selected_index between 0 and 3),
  is_correct boolean,
  primary key (attempt_id, question_id)
);

-- ---------- POINTS AND REWARDS ----------
-- Points are a ledger. Only owner-run functions add rows.
create table public.points_ledger (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  points integer not null check (points <> 0),
  reason text not null,
  source_ref text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index points_ledger_user_idx on public.points_ledger (user_id);

create table public.rewards (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  reward_type text not null check (reward_type in ('mobile_data', 'airtime', 'learning_material', 'badge')),
  description text,
  points_cost integer not null check (points_cost > 0),
  quantity_available integer check (quantity_available is null or quantity_available >= 0),
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);

-- Gift links store only a hash of the token, so a database leak cannot reveal live links.
create table public.gift_links (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique,
  user_id uuid not null references public.profiles(id) on delete cascade,
  reward_id uuid not null references public.rewards(id) on delete restrict,
  status text not null default 'active' check (status in ('active', 'used', 'revoked', 'expired')),
  expires_at timestamptz not null,
  used_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.redemption_requests (
  id uuid primary key default gen_random_uuid(),
  gift_link_id uuid references public.gift_links(id) on delete set null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  reward_id uuid not null references public.rewards(id) on delete restrict,
  network text,
  phone text,
  status text not null default 'requested' check (status in ('requested', 'approved', 'delivered', 'cancelled')),
  owner_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
-- One redemption per gift link.
create unique index redemption_one_per_link on public.redemption_requests (gift_link_id) where gift_link_id is not null;

-- ---------- STUDY GROUPS (owner creates) ----------
create table public.study_groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  join_code_hash text unique,
  is_closed boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.group_memberships (
  group_id uuid not null references public.study_groups(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);

-- ---------- COACHING SESSIONS ----------
create table public.coaching_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject_id uuid references public.subjects(id) on delete set null,
  host_id uuid references public.profiles(id) on delete set null,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status text not null default 'scheduled' check (status in ('scheduled', 'live', 'ended', 'cancelled')),
  room_name text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table public.subjects enable row level security;
alter table public.syllabus_topics enable row level security;
alter table public.question_bank enable row level security;
alter table public.cbt_exams enable row level security;
alter table public.cbt_exam_questions enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.exam_answers enable row level security;
alter table public.points_ledger enable row level security;
alter table public.rewards enable row level security;
alter table public.gift_links enable row level security;
alter table public.redemption_requests enable row level security;
alter table public.study_groups enable row level security;
alter table public.group_memberships enable row level security;
alter table public.coaching_sessions enable row level security;

-- Owner-only management on every table in this file.
create policy "owner_all_subjects" on public.subjects for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_topics" on public.syllabus_topics for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_questions" on public.question_bank for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_exams" on public.cbt_exams for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_exam_questions" on public.cbt_exam_questions for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_attempts" on public.exam_attempts for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_answers" on public.exam_answers for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_points" on public.points_ledger for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_rewards" on public.rewards for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_gift_links" on public.gift_links for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_redemptions" on public.redemption_requests for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_groups" on public.study_groups for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_memberships" on public.group_memberships for all to authenticated using (public.is_owner()) with check (public.is_owner());
create policy "owner_all_coaching" on public.coaching_sessions for all to authenticated using (public.is_owner()) with check (public.is_owner());

-- Limited read access for students. Each row is one the student is allowed to see.
create policy "active_students_read_subjects" on public.subjects for select to authenticated
  using (is_active and exists (select 1 from public.profiles p where p.id = auth.uid() and p.account_status = 'active'));

create policy "active_students_read_topics" on public.syllabus_topics for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.account_status = 'active'));

create policy "students_read_own_points" on public.points_ledger for select to authenticated
  using (user_id = auth.uid());

create policy "students_read_active_rewards" on public.rewards for select to authenticated
  using (is_active);

create policy "students_read_own_redemptions" on public.redemption_requests for select to authenticated
  using (user_id = auth.uid());

create policy "students_read_own_memberships" on public.group_memberships for select to authenticated
  using (user_id = auth.uid());

create policy "members_read_their_groups" on public.study_groups for select to authenticated
  using (exists (select 1 from public.group_memberships m where m.group_id = id and m.user_id = auth.uid()));

create policy "students_read_own_attempts" on public.exam_attempts for select to authenticated
  using (user_id = auth.uid());
