-- =====================================================================
-- SKILLFORGE, Phase 1: accounts, roles, manual payments, receipts
-- Run this file first, in the Supabase SQL Editor (or with the Supabase CLI).
-- =====================================================================

-- ---------- PROFILES ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 3 and 100),
  username text not null check (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  phone text not null check (phone ~ '^\+?[0-9]{10,15}$'),
  email text not null,
  department text not null check (department in ('Science', 'Art', 'Commercial')),
  role text not null default 'student' check (role in ('student', 'owner')),
  account_status text not null default 'pending_payment' check (account_status in (
    'pending_payment', 'payment_under_review', 'payment_approved',
    'entrance_pending', 'active', 'suspended'
  )),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index profiles_username_lower_idx on public.profiles (lower(username));
create index profiles_status_idx on public.profiles (account_status);

-- ---------- ROLE HELPER ----------
-- Security definer so policies can check the role without recursion.
create or replace function public.is_owner()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'owner'
  );
$$;

-- Used by the registration form to check usernames before signup.
create or replace function public.is_username_available(p_username text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select not exists (
    select 1 from public.profiles where lower(username) = lower(p_username)
  );
$$;

grant execute on function public.is_username_available(text) to anon, authenticated;

-- ---------- CREATE PROFILE ON SIGNUP ----------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, username, phone, email, department)
  values (
    new.id,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'username',
    new.raw_user_meta_data->>'phone',
    new.email,
    new.raw_user_meta_data->>'department'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- PROTECT SENSITIVE PROFILE FIELDS ----------
-- Students update their profile directly through the API. This trigger stops
-- them from changing their role, account status, username, department or email.
-- Changes made inside security definer functions (running as postgres) are allowed.
create or replace function public.protect_profile_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if current_user in ('anon', 'authenticated') then
    if new.id <> old.id
       or new.role <> old.role
       or new.account_status <> old.account_status
       or new.username <> old.username
       or new.department <> old.department
       or new.email <> old.email then
      raise exception 'This field can only be changed by the SKILLFORGE owner.';
    end if;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger profiles_protect_fields
  before update on public.profiles
  for each row execute function public.protect_profile_fields();

alter table public.profiles enable row level security;

create policy "profiles_select_own_or_owner"
  on public.profiles for select
  to authenticated
  using (id = auth.uid() or public.is_owner());

create policy "profiles_update_own"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- No insert or delete policies: profiles are created by the signup trigger only.

-- ---------- AUDIT LOG ----------
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_table text,
  target_id text,
  details jsonb,
  created_at timestamptz not null default now()
);

alter table public.audit_logs enable row level security;

create policy "audit_logs_owner_read"
  on public.audit_logs for select
  to authenticated
  using (public.is_owner());

-- ---------- PAYMENT SUBMISSIONS ----------
create table public.payment_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  amount_ngn integer not null default 500 check (amount_ngn = 500),
  payment_reference text not null check (char_length(payment_reference) between 6 and 60),
  payment_date date not null,
  receipt_path text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  rejection_reason text,
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check (status <> 'rejected' or rejection_reason is not null)
);

-- A student can have only one payment waiting for review at a time.
create unique index payment_one_pending_per_user
  on public.payment_submissions (user_id) where status = 'pending';

-- The same transfer reference cannot be used twice (rejected entries are excluded).
create unique index payment_reference_unique
  on public.payment_submissions (lower(payment_reference)) where status <> 'rejected';

create index payment_status_created_idx on public.payment_submissions (status, created_at);

alter table public.payment_submissions enable row level security;

create policy "payments_select_own_or_owner"
  on public.payment_submissions for select
  to authenticated
  using (user_id = auth.uid() or public.is_owner());

-- No insert, update or delete policies. All writes go through the functions below.

-- ---------- STUDENT: SUBMIT PAYMENT ----------
create or replace function public.submit_payment(
  p_reference text,
  p_payment_date date,
  p_receipt_path text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_status text;
  v_ref text := btrim(p_reference);
  v_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Please log in first.';
  end if;

  select account_status into v_status from public.profiles where id = auth.uid();
  if v_status is null then
    raise exception 'Your profile could not be found.';
  end if;
  if v_status <> 'pending_payment' then
    raise exception 'Your payment is already submitted, or your account is past the payment step.';
  end if;

  if char_length(v_ref) < 6 then
    raise exception 'Enter the payment reference or transaction ID.';
  end if;

  if p_payment_date is null or p_payment_date > current_date then
    raise exception 'Enter a valid payment date that is not in the future.';
  end if;

  -- Receipts must live in the student's own folder.
  if p_receipt_path is not null and split_part(p_receipt_path, '/', 1) <> auth.uid()::text then
    raise exception 'Invalid receipt location.';
  end if;

  insert into public.payment_submissions (user_id, payment_reference, payment_date, receipt_path)
  values (auth.uid(), v_ref, p_payment_date, p_receipt_path)
  returning id into v_id;

  update public.profiles set account_status = 'payment_under_review' where id = auth.uid();

  insert into public.audit_logs (actor_id, action, target_table, target_id)
  values (auth.uid(), 'payment.submitted', 'payment_submissions', v_id::text);

  return v_id;
end;
$$;

-- ---------- OWNER: APPROVE PAYMENT ----------
create or replace function public.approve_payment(p_submission_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_status text;
begin
  if not public.is_owner() then
    raise exception 'Only the owner can approve payments.';
  end if;

  select user_id, status into v_user, v_status
  from public.payment_submissions
  where id = p_submission_id
  for update;

  if v_user is null then
    raise exception 'Payment not found.';
  end if;
  if v_status <> 'pending' then
    raise exception 'This payment has already been reviewed.';
  end if;

  update public.payment_submissions
  set status = 'approved', reviewed_by = auth.uid(), reviewed_at = now(), rejection_reason = null
  where id = p_submission_id;

  update public.profiles set account_status = 'payment_approved' where id = v_user;

  insert into public.audit_logs (actor_id, action, target_table, target_id, details)
  values (auth.uid(), 'payment.approved', 'payment_submissions', p_submission_id::text,
          jsonb_build_object('student_id', v_user));
end;
$$;

-- ---------- OWNER: REJECT PAYMENT ----------
create or replace function public.reject_payment(p_submission_id uuid, p_reason text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_status text;
begin
  if not public.is_owner() then
    raise exception 'Only the owner can reject payments.';
  end if;
  if char_length(btrim(coalesce(p_reason, ''))) < 5 then
    raise exception 'Give a reason of at least 5 characters.';
  end if;

  select user_id, status into v_user, v_status
  from public.payment_submissions
  where id = p_submission_id
  for update;

  if v_user is null then
    raise exception 'Payment not found.';
  end if;
  if v_status <> 'pending' then
    raise exception 'This payment has already been reviewed.';
  end if;

  update public.payment_submissions
  set status = 'rejected', rejection_reason = btrim(p_reason), reviewed_by = auth.uid(), reviewed_at = now()
  where id = p_submission_id;

  -- The student returns to the payment step and may resubmit.
  update public.profiles set account_status = 'pending_payment' where id = v_user;

  insert into public.audit_logs (actor_id, action, target_table, target_id, details)
  values (auth.uid(), 'payment.rejected', 'payment_submissions', p_submission_id::text,
          jsonb_build_object('student_id', v_user, 'reason', btrim(p_reason)));
end;
$$;

-- ---------- OWNER: SET ACCOUNT STATUS ----------
-- Phase 1 exposes this function only. The UI for it comes later.
-- In Phase 2, 'active' should be set by the entrance examination result.
create or replace function public.set_account_status(p_user uuid, p_status text, p_reason text default null)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_owner() then
    raise exception 'Only the owner can change account status.';
  end if;
  if p_status not in ('pending_payment','payment_under_review','payment_approved','entrance_pending','active','suspended') then
    raise exception 'Unknown account status.';
  end if;

  update public.profiles set account_status = p_status where id = p_user;

  insert into public.audit_logs (actor_id, action, target_table, target_id, details)
  values (auth.uid(), 'account.status_changed', 'profiles', p_user::text,
          jsonb_build_object('status', p_status, 'reason', p_reason));
end;
$$;

-- Lock down function execution: only signed-in users can call these.
revoke execute on function public.submit_payment(text, date, text) from public, anon;
revoke execute on function public.approve_payment(uuid) from public, anon;
revoke execute on function public.reject_payment(uuid, text) from public, anon;
revoke execute on function public.set_account_status(uuid, text, text) from public, anon;
grant execute on function public.submit_payment(text, date, text) to authenticated;
grant execute on function public.approve_payment(uuid) to authenticated;
grant execute on function public.reject_payment(uuid, text) to authenticated;
grant execute on function public.set_account_status(uuid, text, text) to authenticated;

-- ---------- PRIVATE RECEIPT STORAGE ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'payment-receipts',
  'payment-receipts',
  false,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
)
on conflict (id) do nothing;

create policy "receipts_insert_own_folder"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'payment-receipts'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "receipts_read_own_or_owner"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'payment-receipts'
    and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner())
  );

-- =====================================================================
-- After the owner registers normally on the site, run this ONCE in the
-- SQL Editor to make that account the owner. Replace the email if needed.
--
--   update public.profiles set role = 'owner'
--   where email = 'ogunlowosodiq19@gmail.com';
--
-- Do not create a public admin sign-up page. This is the only way to
-- create an owner, and it is done by you, the database administrator.
-- =====================================================================
